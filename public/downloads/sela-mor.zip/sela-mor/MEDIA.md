# Media for Sela Mor, sound artist and composer from Baku

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/ambientSound.mp3` | sound | — | left out |
| `public/media/field-recording.jpg` | photo | 2400×1581 px | placeholder |
| `public/media/gallery-1.jpg` | photo | 1714×2400 px | placeholder |
| `public/media/gallery-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-5.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/gallery-6.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/gallery-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-8.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 10 s | left out |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 10 s | left out |
| `public/media/portrait.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 10 s | left out |
| `public/media/stage.jpg` | photo | 2400×1351 px | placeholder |
| `public/media/tracks/machine-hymns.mp3` | sound | — | left out |
| `public/media/tracks/night-shift.mp3` | sound | — | left out |
| `public/media/tracks/rain-caspian.mp3` | sound | — | left out |
| `public/media/tracks/room-tone.mp3` | sound | — | left out |
| `public/media/tracks/salt-flats.mp3` | sound | — | left out |
| `public/media/tracks/wind-archive.mp3` | sound | — | left out |
| `public/media/work-live.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/work-machine.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/work-rain.jpg` | photo | 2400×2227 px | placeholder |
| `public/media/work-room.jpg` | photo | 2400×1677 px | placeholder |
| `public/media/work-wind.jpg` | photo | 2400×1600 px | placeholder |

Run it: `npm install && npm run dev`.
