# Media for Hane, physiotherapy and slow movement

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 1600x908 px, 14 s | left out |
| `public/media/clips/contact-cta.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/faq.mp4` | video | 1280x720 px, 4 s | left out |
| `public/media/clips/footer.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/how-it-works.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/location.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/navbar.mp4` | video | 1280x720 px, 5 s | left out |
| `public/media/clips/piece-underline-fill.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/pricing.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/reservation.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/services.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/sig-guided-stops.mp4` | video | 1280x726 px, 4 s | left out |
| `public/media/clips/sig-live-status.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/team.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/testimonials.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/hero-1600.webp` | photo | 1600×2400 px | placeholder |
| `public/media/hero-800.webp` | photo | 800×1200 px | placeholder |
| `public/media/hero.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/location-1600.webp` | photo | 1600×1003 px | placeholder |
| `public/media/location-800.webp` | photo | 800×502 px | placeholder |
| `public/media/location.jpg` | photo | 2400×1504 px | placeholder |
| `public/media/step-1-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/step-1-800.webp` | photo | 800×534 px | placeholder |
| `public/media/step-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/step-2-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/step-2-800.webp` | photo | 800×534 px | placeholder |
| `public/media/step-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/step-3-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/step-3-800.webp` | photo | 800×534 px | placeholder |
| `public/media/step-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/team-1-1600.webp` | photo | 1600×2134 px | placeholder |
| `public/media/team-1-800.webp` | photo | 800×1067 px | placeholder |
| `public/media/team-1.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/team-2-1600.webp` | photo | 1600×2000 px | placeholder |
| `public/media/team-2-800.webp` | photo | 800×1000 px | placeholder |
| `public/media/team-2.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/team-3-1600.webp` | photo | 1600×2400 px | placeholder |
| `public/media/team-3-800.webp` | photo | 800×1200 px | placeholder |
| `public/media/team-3.jpg` | photo | 1600×2400 px | placeholder |

Run it: `npm install && npm run dev`.
