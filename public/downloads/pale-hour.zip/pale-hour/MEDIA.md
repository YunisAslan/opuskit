# Media for Pale Hour, photography gallery and bookshop

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/featuredWork-1.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/featuredWork-2.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/featuredWork-3.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/featuredWork-4.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/gallery-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/hero.jpg` | photo | 2800×1575 px | placeholder |
| `public/media/journal-1.jpg` | photo | 2000×1333 px | placeholder |
| `public/media/journal-2.jpg` | photo | 2000×1333 px | placeholder |
| `public/media/journal-3.jpg` | photo | 2000×1333 px | placeholder |
| `public/media/location.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/mobileHeroCrop.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/team-1.jpg` | photo | 1500×2000 px | placeholder |
| `public/media/team-2.jpg` | photo | 1500×2000 px | placeholder |
| `public/media/team-3.jpg` | photo | 1500×2000 px | placeholder |
| `public/media/team-4.jpg` | photo | 1500×2000 px | placeholder |

Run it: `npm install && npm run dev`.
