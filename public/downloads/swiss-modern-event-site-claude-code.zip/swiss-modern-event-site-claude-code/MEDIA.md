# Media for RALPH&LAUREN — Sheki Polo Weekend, 11–13 June 2027

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/heroVideo.mp4` | video | 1920x1078 px, 14 s | left out |
| `public/media/mobileVideoEncode.mp4` | video | 682x1212 px, 14 s | left out |
| `public/media/photos/arena.jpg` | photo | 2400×1802 px | placeholder |
| `public/media/photos/box.jpg` | photo | 2400×1920 px | placeholder |
| `public/media/photos/chestnut.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/photos/gallop.jpg` | photo | 1858×2400 px | placeholder |
| `public/media/photos/groom.jpg` | photo | 1602×2400 px | placeholder |
| `public/media/photos/herd.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/photos/jump.jpg` | photo | 2400×1590 px | placeholder |
| `public/media/photos/palomino.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/photos/ponies.jpg` | photo | 2400×1838 px | placeholder |
| `public/media/photos/rider-grey.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/photos/stables.jpg` | photo | 2400×1800 px | placeholder |
| `public/media/posterImage.jpg` | photo | 1920×1078 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 682×1212 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1078 px, 14 s | left out |

Run it: `npm install && npm run dev`.
