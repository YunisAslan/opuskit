# Media for Keepers — Citrus Coffee Soda

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/beans.jpg` | photo | 1600×1220 px | placeholder |
| `public/media/canDetail.jpg` | photo | 1728×992 px | placeholder |
| `public/media/canFinal.jpg` | photo | 1728×992 px | placeholder |
| `public/media/canFloat.jpg` | photo | 1728×992 px | placeholder |
| `public/media/clip.mp4` | video | 1728x992 px, 8 s | left out |
| `public/media/founderLena.jpg` | photo | 1200×1800 px | placeholder |
| `public/media/founderMarco.jpg` | photo | 1200×1800 px | placeholder |
| `public/media/glassIce.jpg` | photo | 1728×992 px | placeholder |
| `public/media/glassPour.jpg` | photo | 1728×992 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1728x992 px, 15 s | left out |
| `public/media/ingredients.jpg` | photo | 1728×992 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 558x992 px, 15 s | left out |
| `public/media/posterImage.jpg` | photo | 1728×992 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/pour.jpg` | photo | 1728×992 px | placeholder |
| `public/media/ringpull.jpg` | photo | 1728×992 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1728x992 px, 15 s | left out |

Run it: `npm install && npm run dev`.
