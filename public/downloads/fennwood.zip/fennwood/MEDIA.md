# Media for Fennwood, a wood-fire kitchen in Bristol

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 1600x908 px, 13 s | left out |
| `public/media/clips/faq.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/footer.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/gallery.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/intro.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/location.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/menu.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/navbar.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/piece-cut-reveal.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/piece-scribble-link.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/reservation.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/sig-footer-moment.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/sig-travelling-motif.mp4` | video | 1280x720 px, 5 s | left out |
| `public/media/dish-1-1080.webp` | photo | 1080×719 px | placeholder |
| `public/media/dish-1-1600.webp` | photo | 1600×1065 px | placeholder |
| `public/media/dish-1-2400.webp` | photo | 2400×1597 px | placeholder |
| `public/media/dish-1-320.webp` | photo | 320×213 px | placeholder |
| `public/media/dish-1-640.webp` | photo | 640×426 px | placeholder |
| `public/media/dish-1.jpg` | photo | 2400×1597 px | placeholder |
| `public/media/dish-2-1080.webp` | photo | 1080×720 px | placeholder |
| `public/media/dish-2-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/dish-2-2400.webp` | photo | 2400×1600 px | placeholder |
| `public/media/dish-2-320.webp` | photo | 320×214 px | placeholder |
| `public/media/dish-2-640.webp` | photo | 640×427 px | placeholder |
| `public/media/dish-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/dish-3-1080.webp` | photo | 1080×810 px | placeholder |
| `public/media/dish-3-1600.webp` | photo | 1600×1200 px | placeholder |
| `public/media/dish-3-2400.webp` | photo | 2400×1800 px | placeholder |
| `public/media/dish-3-320.webp` | photo | 320×240 px | placeholder |
| `public/media/dish-3-640.webp` | photo | 640×480 px | placeholder |
| `public/media/dish-3.jpg` | photo | 2400×1800 px | placeholder |
| `public/media/farm-1080.webp` | photo | 1080×688 px | placeholder |
| `public/media/farm-1600.webp` | photo | 1600×1018 px | placeholder |
| `public/media/farm-2400.webp` | photo | 2400×1527 px | placeholder |
| `public/media/farm-320.webp` | photo | 320×204 px | placeholder |
| `public/media/farm-640.webp` | photo | 640×408 px | placeholder |
| `public/media/farm.jpg` | photo | 2400×1527 px | placeholder |
| `public/media/hero-1080.webp` | photo | 1080×1620 px | placeholder |
| `public/media/hero-1600.webp` | photo | 1600×2400 px | placeholder |
| `public/media/hero-2400.webp` | photo | 2400×3600 px | placeholder |
| `public/media/hero-320.webp` | photo | 320×480 px | placeholder |
| `public/media/hero-640.webp` | photo | 640×960 px | placeholder |
| `public/media/hero-mobile-1080.webp` | photo | 1080×1920 px | placeholder |
| `public/media/hero-mobile-1600.webp` | photo | 1440×2560 px | placeholder |
| `public/media/hero-mobile-2400.webp` | photo | 1440×2560 px | placeholder |
| `public/media/hero-mobile-320.webp` | photo | 320×569 px | placeholder |
| `public/media/hero-mobile-640.webp` | photo | 640×1138 px | placeholder |
| `public/media/hero-mobile.jpg` | photo | 1440×2560 px | placeholder |
| `public/media/hero.jpg` | photo | 2400×3600 px | placeholder |
| `public/media/location-1080.webp` | photo | 1080×579 px | placeholder |
| `public/media/location-1600.webp` | photo | 1600×857 px | placeholder |
| `public/media/location-2400.webp` | photo | 2400×1285 px | placeholder |
| `public/media/location-320.webp` | photo | 320×172 px | placeholder |
| `public/media/location-640.webp` | photo | 640×343 px | placeholder |
| `public/media/location.jpg` | photo | 2400×1285 px | placeholder |
| `public/media/room-1-1080.webp` | photo | 1080×720 px | placeholder |
| `public/media/room-1-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/room-1-2400.webp` | photo | 2400×1600 px | placeholder |
| `public/media/room-1-320.webp` | photo | 320×214 px | placeholder |
| `public/media/room-1-640.webp` | photo | 640×427 px | placeholder |
| `public/media/room-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/room-2-1080.webp` | photo | 1080×720 px | placeholder |
| `public/media/room-2-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/room-2-2400.webp` | photo | 2400×1600 px | placeholder |
| `public/media/room-2-320.webp` | photo | 320×214 px | placeholder |
| `public/media/room-2-640.webp` | photo | 640×427 px | placeholder |
| `public/media/room-2.jpg` | photo | 2400×1600 px | placeholder |

Run it: `npm install && npm run dev`.
