# Media for Pip & Kiln — bright mugs, plates and vases

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/categories-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/categories-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/categories-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/categories-4.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/collection-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/collection-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/collection-3.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/collection-4.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/gallery-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/hero.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/productGrid-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productGrid-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productGrid-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productGrid-4.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productGrid-5.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productGrid-6.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productHighlight.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/productPageBuy/big-hug-mug-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/big-hug-mug-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/big-hug-mug-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/bud-buddy-vase-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/bud-buddy-vase-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/bud-buddy-vase-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/morning-person-mug-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/morning-person-mug-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/morning-person-mug-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/second-helping-plate-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/second-helping-plate-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/second-helping-plate-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/show-off-vase-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/show-off-vase-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/show-off-vase-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/sunny-side-plate-1.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/sunny-side-plate-2.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageBuy/sunny-side-plate-3.jpg` | photo | 1333×2000 px | placeholder |
| `public/media/productPageHighlight/big-hug-mug-1.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/productPageHighlight/bud-buddy-vase-1.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/productPageHighlight/morning-person-mug-1.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/productPageHighlight/second-helping-plate-1.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/productPageHighlight/show-off-vase-1.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/productPageHighlight/sunny-side-plate-1.jpg` | photo | 2400×2400 px | placeholder |

Run it: `npm install && npm run dev`.
