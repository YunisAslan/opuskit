# Media for Ninth Row — arthouse cinema, a film every night

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/featuredWork-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/featuredWork-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/featuredWork-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/featuredWork-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 8 s | left out |
| `public/media/location.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 8 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 8 s | left out |
| `public/media/team-1.jpg` | photo | 2000×1333 px | placeholder |
| `public/media/team-2.jpg` | photo | 2000×1333 px | placeholder |
| `public/media/team-3.jpg` | photo | 2000×1333 px | placeholder |
| `public/media/team-4.jpg` | photo | 2000×1333 px | placeholder |

Run it: `npm install && npm run dev`.
