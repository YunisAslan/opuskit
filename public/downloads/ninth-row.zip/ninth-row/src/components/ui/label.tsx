"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return <label data-slot="label" className={cn("type-utility block text-(--color-muted) select-none", className)} {...props} />
}

export { Label }
