# Media for Brasshand, a branding studio in Baku

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/studio.jpg` | photo | 2400×1585 px | placeholder |
| `public/media/team-1.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/team-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/team-3.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/work-1.jpg` | photo | 2400×1447 px | placeholder |
| `public/media/work-2.jpg` | photo | 2400×1460 px | placeholder |
| `public/media/work-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/work-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/work-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/work-6.jpg` | photo | 2400×1600 px | placeholder |

Run it: `npm install && npm run dev`.
