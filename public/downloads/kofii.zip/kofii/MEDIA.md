# Media for KOFİİ — Coffee, made to order

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 1920x1080 px, 8 s | left out |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 29 s | left out |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 29 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 29 s | left out |
| `public/media/yourPhotos-1.jpg` | photo | 563×1000 px | placeholder |
| `public/media/yourPhotos-2.jpg` | photo | 570×1000 px | placeholder |
| `public/media/yourPhotos-3.jpg` | photo | 512×512 px | placeholder |
| `public/media/yourPhotos-4.png` | photo | 1152×2048 px | placeholder |
| `public/media/yourPhotos-5.jpg` | photo | 736×1308 px | placeholder |
| `public/media/yourPhotos-6.jpg` | photo | 632×1000 px | placeholder |
| `public/media/yourPhotos-7.jpg` | photo | 559×1000 px | placeholder |
| `public/media/yourPhotos-8.jpg` | photo | 595×1000 px | placeholder |
| `public/media/yourPhotos-9.jpg` | photo | 736×1349 px | placeholder |

Run it: `npm install && npm run dev`.
