# Media for Velmira, a lake house in the Gabala hills

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/ambientSound.mp3` | sound | — | left out |
| `public/media/arrival.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/bath.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/gallery-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/gallery-3.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/gallery-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 14 s | left out |
| `public/media/lake.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 14 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/room-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/room-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/room-3.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/sauna.jpg` | photo | 2400×1702 px | placeholder |

Run it: `npm install && npm run dev`.
