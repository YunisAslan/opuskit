# Media for Night Shift: learn film colour grading, live, in eight weeks

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/console-poster-mobile.jpg` | photo | 1080×1350 px | placeholder |
| `public/media/console-poster.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/grade-1.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/grade-2.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/grade-3.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/instructor.jpg` | photo | 1590×2400 px | placeholder |
| `public/media/log-1.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/log-2.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/log-3.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/monitor-poster.jpg` | photo | 1280×720 px | placeholder |
| `public/media/monitor.mp4` | video | 1280x720 px, 8 s | left out |
| `public/media/scope.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/set-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/set-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/set-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/student-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/student-2.jpg` | photo | 1590×2400 px | placeholder |
| `public/media/suite.jpg` | photo | 2400×1213 px | placeholder |

Run it: `npm install && npm run dev`.
