# Media for BUYTOLOSE — Fleece, carry and snacks

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about-portrait.webp` | photo | 1000×1250 px | placeholder |
| `public/media/clip.mp4` | video | 1920x1440 px, 8 s | left out |
| `public/media/closing-wide.webp` | photo | 1600×900 px | placeholder |
| `public/media/collection-tall.webp` | photo | 1000×1250 px | placeholder |
| `public/media/collection-wide.webp` | photo | 1600×900 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1440 px, 12 s | left out |
| `public/media/highlight-1.webp` | photo | 1600×1200 px | placeholder |
| `public/media/highlight-2.webp` | photo | 1600×1200 px | placeholder |
| `public/media/highlight-3.webp` | photo | 1600×1200 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 12 s | left out |
| `public/media/posterImage.webp` | photo | 1920×1440 px | placeholder |
| `public/media/posterMobile.webp` | photo | 1080×1920 px | placeholder |
| `public/media/product-cap-a.webp` | photo | 800×1000 px | placeholder |
| `public/media/product-cap-b.webp` | photo | 800×1000 px | placeholder |
| `public/media/product-crisps-a.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-crisps-b.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-cup-a.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-cup-b.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-hoodie-a.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-hoodie-b.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-pant-a.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-pant-b.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-sling-a.webp` | photo | 1000×1250 px | placeholder |
| `public/media/product-sling-b.webp` | photo | 1000×1250 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1440 px, 12 s | left out |
| `public/media/secondaryVideo.mp4` | video | 1280x960 px, 2 s | left out |

Run it: `npm install && npm run dev`.
