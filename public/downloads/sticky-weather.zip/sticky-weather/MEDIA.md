# Media for Sticky Weather, a design studio for brands that want to be picked up

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 1600x908 px, 12 s | left out |
| `public/media/clips/about.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/contact-cta.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/featured-work.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/footer.mp4` | video | 1280x720 px, 4 s | left out |
| `public/media/clips/journal.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/manifesto.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/navbar.mp4` | video | 1280x720 px, 4 s | left out |
| `public/media/clips/piece-brand-cursor.mp4` | video | 1280x720 px, 4 s | left out |
| `public/media/clips/piece-text-effect.mp4` | video | 1280x726 px, 4 s | left out |
| `public/media/clips/piece-wavy-link.mp4` | video | 1280x720 px, 4 s | left out |
| `public/media/clips/sig-entry-gate.mp4` | video | 1280x726 px, 4 s | left out |
| `public/media/clips/sig-theme-per-variant.mp4` | video | 1280x726 px, 4 s | left out |
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/studio-1.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/studio-2.jpg` | photo | 2400×1799 px | placeholder |
| `public/media/studio-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/studio-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/studio-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/team-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/team-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/team-3.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/work-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/work-2.jpg` | photo | 1499×2400 px | placeholder |
| `public/media/work-3.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/work-4.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/work-5.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/work-6.jpg` | photo | 1600×2400 px | placeholder |

Run it: `npm install && npm run dev`.
