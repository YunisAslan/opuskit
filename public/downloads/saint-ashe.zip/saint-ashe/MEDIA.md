# Media for Saint Ashe | Black clothing cut in small runs in Tbilisi

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/detail.jpg` | photo | 2400×1656 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 11 s | left out |
| `public/media/look-1.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/look-2.jpg` | photo | 1886×2400 px | placeholder |
| `public/media/look-3.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 608x1080 px, 11 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 608×1080 px | placeholder |
| `public/media/product-1.jpg` | photo | 1322×2400 px | placeholder |
| `public/media/product-2.jpg` | photo | 2229×2400 px | placeholder |
| `public/media/product-3.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/product-4.jpg` | photo | 1882×2400 px | placeholder |
| `public/media/product-5.jpg` | photo | 1662×2400 px | placeholder |
| `public/media/product-6.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/product-7.jpg` | photo | 1614×2400 px | placeholder |
| `public/media/product-8.jpg` | photo | 2400×2051 px | placeholder |
| `public/media/shop.jpg` | photo | 2400×2094 px | placeholder |
| `public/media/studio.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/team-1.jpg` | photo | 1601×2400 px | placeholder |
| `public/media/team-2.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/team-3.jpg` | photo | 1601×2400 px | placeholder |

Run it: `npm install && npm run dev`.
