# Media for Hexmint: invoices, expenses and quarterly books for small studios

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 1600x908 px, 14 s | left out |
| `public/media/clips/clients.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/contact-cta.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/faq.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/feature-grid.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/feature-rows.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/footer.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/how-it-works.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/integrations.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/navbar.mp4` | video | 1280x720 px, 4 s | left out |
| `public/media/clips/piece-curtain-transition.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/piece-text-effect.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/piece-text-scramble.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/product-highlight.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/testimonials.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/hero-poster-mobile.jpg` | photo | 780×1046 px | placeholder |
| `public/media/hero-poster.jpg` | photo | 2160×1350 px | placeholder |
| `public/media/render-books.jpg` | photo | 1600×1200 px | placeholder |
| `public/media/render-close.jpg` | photo | 1400×1400 px | placeholder |
| `public/media/render-expenses.jpg` | photo | 1600×1200 px | placeholder |
| `public/media/render-invoices.jpg` | photo | 1600×1200 px | placeholder |

Run it: `npm install && npm run dev`.
