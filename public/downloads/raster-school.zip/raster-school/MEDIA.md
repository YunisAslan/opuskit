# Media for Raster School, an evening course in typographic design

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about.jpg` | photo | 2400×1800 px | placeholder |
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/team-1.jpg` | photo | 2000×2000 px | placeholder |
| `public/media/team-2.jpg` | photo | 2000×2000 px | placeholder |
| `public/media/team-3.jpg` | photo | 2000×2000 px | placeholder |
| `public/media/team-4.jpg` | photo | 2000×2000 px | placeholder |

Run it: `npm install && npm run dev`.
