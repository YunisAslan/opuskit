# Media for ulooklonely

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 20 s | left out |
| `public/media/mobileVideoEncode.mp4` | video | 720x1280 px, 20 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 720×1280 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 20 s | left out |
| `public/media/stills/still-00-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-00.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-01-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-01.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-02-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-02.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-03-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-03.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-04-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-04.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-05-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-05.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-06-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-06.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-07-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-07.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-08-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-08.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-09-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-09.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-10-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-10.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-11-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-11.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-12-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-12.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-13-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-13.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-14-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-14.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-15-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-15.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-17-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-17.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-18-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-18.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-19-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-19.jpg` | photo | 1280×720 px | placeholder |
| `public/media/stills/still-20-sm.jpg` | photo | 640×360 px | placeholder |
| `public/media/stills/still-20.jpg` | photo | 1280×720 px | placeholder |

Run it: `npm install && npm run dev`.
