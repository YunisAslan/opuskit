# Media for Maison Vey, five scents made by hand

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about-portrait.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/collection-discovery-set.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/collection-fig-courtyard.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/collection-night-ferry.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/collection-orangery.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/collection-reading-room.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/collection-salt-quay.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/editorial-hands.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/editorial-place.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/hero-mobile.jpg` | photo | 2240×2800 px | placeholder |
| `public/media/hero.jpg` | photo | 2800×1575 px | placeholder |
| `public/media/highlight-salt-quay.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/lifestyleImages.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/product-discovery-set-angle.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-discovery-set-detail.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/product-discovery-set.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-fig-courtyard-angle.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-fig-courtyard-detail.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/product-fig-courtyard.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-night-ferry-angle.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-night-ferry-detail.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/product-night-ferry.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-orangery-angle.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-orangery-detail.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/product-orangery.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-reading-room-angle.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-reading-room-detail.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/product-reading-room.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-salt-quay-angle.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/product-salt-quay-detail.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/product-salt-quay.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/productPhotography.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/turntableSequence.jpg` | photo | 2400×2400 px | placeholder |

Run it: `npm install && npm run dev`.
