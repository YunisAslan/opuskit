---
name: visual-qa
description: Compares the implemented site against the Halvik — Bento Product Launch recipe and lists deviations. Use after finishing a section or page, before declaring work done, or when asked to review the design.
---

# Visual QA

Run the dev server, open each page (use a browser/screenshot tool if available), and compare against the recipe. Report deviations as a list: section → expected → actual → fix.

## Checklist
- [ ] Background is #9D91E3; no other page background colors are introduced.
- [ ] Display text uses Hubot Sans 800; body uses IBM Plex Sans; no other families appear.
- [ ] Accent #000000 covers < 5% of any viewport.
- [ ] Pages: Home · Features · Contact — every page shares the same navbar and footer.
- [ ] Footer “Signature columns”: Dark band (text colour as ground): the logo large on the left (5 of 12 columns), 2–3 link columns with headings, then a hairline and one row: copyright left, legal links right.
- [ ] Home section order: Hero → Product Highlight → Feature Rows → Press → Testimonials → Pricing → Trust Strip → Closing CTA.
- [ ] Features section order: Features → How It Works → Product Highlight → Closing CTA.
- [ ] Contact section order: Closing CTA → FAQ.
- [ ] Hero matches "Product stage": The product isolated on a clean surface, large and centred or offset, with name, one-line promise and price/CTA.
- [ ] Controls and forms use shadcn/ui (button, sheet, sonner, tooltip, navigation-menu, dropdown-menu, radio-group, select, badge, tabs, switch, card, input, textarea, checkbox, form, label, accordion) restyled to the recipe tokens and shape — no unstyled native select, date input or checkbox anywhere; the date field is a Calendar in a Popover.
- [ ] Sections with ready code are built from their component in src/components/sections/ (real copy and media through props, no placeholder text left) and styled only through the recipe tokens. Pass the framework link as `link` (Next.js: `link={Link}` from next/link) so in-site links navigate client-side and respect basePath; without it they render plain <a>.
- [ ] Kit piece "Words that arrive" (<TextEffect/> from src/components/pieces/TextEffect.tsx) is used on Every page — the h1 and each section heading, unchanged in behaviour and styled only through the recipe tokens.
- [ ] Kit piece "Filling underline" (<UnderlineFill/> from src/components/pieces/UnderlineFill.tsx) is used on Every page — menu, footer and text links, unchanged in behaviour and styled only through the recipe tokens.
- [ ] Kit piece "Magnetic button" (<Magnetic/> from src/components/pieces/Magnetic.tsx) is used on Every page — the main action, unchanged in behaviour and styled only through the recipe tokens.
- [ ] Kit piece "Smooth scroll" (<SmoothScroll/> from src/components/pieces/SmoothScroll.tsx) is used on Whole site — mount once in app/layout.tsx, unchanged in behaviour and styled only through the recipe tokens.
- [ ] Big idea “One thing guides the scroll” is visible on every page: pick one element from the first screen — the product, the logo mark, a drawn line or a simple shape in the accent colour — and let it leave the hero and travel down the page with the visitor, turning up beside each chapter.
- [ ] Chapters open as the big idea says: Each chapter opens where the motif comes to rest: the motif changes pose or size there, and the chapter title sits next to it.
- [ ] The site ends as the big idea says: The motif comes to rest in the footer, beside the brand name: the journey visibly ends.
- [ ] Signature moment "One shape travels down the page" is built on Home — Hero — Product stage, with its mobile and reduced-motion versions.
- [ ] Signature moment "A footer worth reaching" is built on Footer, with its mobile and reduced-motion versions.
- [ ] Every page passes the award checklist in the recipe (one idea, one unforgettable moment per page, type scale contrast, motion choreography, mobile as its own composition, a designed ending).
- [ ] Layout: Modules snap to 3, 4, 6 or 12 columns; section spacing 96–128px, or sections separated by rules only.
- [ ] Shape “Round”: buttons 14px, cards 24px, media 20px radius (rounded-button / rounded-card / rounded-media) — Large radii on cards and media; nested elements use radius − padding.
- [ ] Menu “Floating pill”: A centred, rounded capsule (max 720px) floating 16px from the top: logo, links, one action; translucent surface with backdrop blur.
- [ ] Absent: Long walls of text.
- [ ] Absent: Many accent colours.
- [ ] Absent: Heavy shadows.
- [ ] Absent: A cream or beige page ground with a clay/terracotta accent.
- [ ] Absent: A near-black ground with one acid-green or orange accent, or tinted charcoal standing in for black.
- [ ] Absent: Small uppercase, letter-spaced monospace labels above every heading.
- [ ] Absent: Numbered markers (01 / 02) on content that is not a real sequence.
- [ ] Absent: Meta strings joined with middle dots or spaced em dashes, and "→" appended to links.
- [ ] Absent: One italic or coloured accent word inside an otherwise plain headline.
- [ ] Absent: Falling back to Inter, Space Grotesk, Syne or Fraunces instead of the recipe's fonts.
- [ ] Mobile (390px): no horizontal scroll, headlines re-broken intentionally, touch targets ≥ 44px.
- [ ] prefers-reduced-motion: every animation has its documented alternative.
- [ ] Every media element is rendered through the asset config layer; temporary assets are listed in the manifest.
- [ ] Lighthouse on mobile: LCP < 2.5s, CLS < 0.1.

Do not mark work complete while any item fails. Fix, then re-check.
