# Media for Halvik 65, a compact aluminium keyboard

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 1600x908 px, 11 s | left out |
| `public/media/clips/contact-cta.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/faq.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/feature-grid.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/feature-rows.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/footer.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/how-it-works.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/navbar.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/piece-text-effect.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/piece-underline-fill.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/press.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/pricing.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/product-highlight.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/sig-footer-moment.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/sig-travelling-motif.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/testimonials.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/trust.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/hero-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/hero-800.webp` | photo | 800×534 px | placeholder |
| `public/media/hero-full.webp` | photo | 2400×1600 px | placeholder |
| `public/media/hero.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/product-1600.webp` | photo | 1067×1600 px | placeholder |
| `public/media/product-2-1600.webp` | photo | 1067×1600 px | placeholder |
| `public/media/product-2-800.webp` | photo | 534×800 px | placeholder |
| `public/media/product-2-full.webp` | photo | 1600×2400 px | placeholder |
| `public/media/product-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/product-800.webp` | photo | 534×800 px | placeholder |
| `public/media/product-full.webp` | photo | 1600×2400 px | placeholder |
| `public/media/product.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/row-1-1600.webp` | photo | 1067×1600 px | placeholder |
| `public/media/row-1-800.webp` | photo | 534×800 px | placeholder |
| `public/media/row-1-full.webp` | photo | 1600×2400 px | placeholder |
| `public/media/row-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/row-2-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/row-2-800.webp` | photo | 800×534 px | placeholder |
| `public/media/row-2-full.webp` | photo | 2400×1600 px | placeholder |
| `public/media/row-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/row-3-1600.webp` | photo | 1600×1067 px | placeholder |
| `public/media/row-3-800.webp` | photo | 800×534 px | placeholder |
| `public/media/row-3-full.webp` | photo | 2400×1600 px | placeholder |
| `public/media/row-3.jpg` | photo | 2400×1600 px | placeholder |

Run it: `npm install && npm run dev`.
