# Media for QUM, skincare from the Caspian salt pans

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/balm.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/bathroom.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/cleanser.jpg` | photo | 1601×2400 px | placeholder |
| `public/media/cream.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/founder-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/founder-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/founder-3.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/hero.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/lab.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/oil.jpg` | photo | 1586×2400 px | placeholder |
| `public/media/ritual-face.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/ritual-hands.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/saffron-close.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/saffron-field.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/salt-aerial.jpg` | photo | 2400×1599 px | placeholder |
| `public/media/salt-crystals.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/salt-lake.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/scrub.jpg` | photo | 1601×2400 px | placeholder |
| `public/media/serum-1.jpg` | photo | 1802×2400 px | placeholder |
| `public/media/serum-2.jpg` | photo | 1802×2400 px | placeholder |
| `public/media/serum-3.jpg` | photo | 2400×1802 px | placeholder |
| `public/media/serum-4.jpg` | photo | 1802×2400 px | placeholder |
| `public/media/toner.jpg` | photo | 2400×1600 px | placeholder |

Run it: `npm install && npm run dev`.
