# Media for CHEEKY, a fashion house for the 911

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/clip.mp4` | video | 720x1280 px, 8 s | left out |
| `public/media/heroVideo.mp4` | video | 720x1280 px, 15 s | left out |
| `public/media/mobileVideoEncode.mp4` | video | 540x960 px, 15 s | left out |
| `public/media/posterImage.jpg` | photo | 720×1280 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 720×1280 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 720x1280 px, 15 s | left out |
| `public/media/texture.png` | photo | 256×256 px | placeholder |
| `public/media/yourPhotos-1.jpg` | photo | 564×699 px | placeholder |
| `public/media/yourPhotos-10.jpg` | photo | 736×1307 px | placeholder |
| `public/media/yourPhotos-11.jpg` | photo | 1152×2048 px | placeholder |
| `public/media/yourPhotos-2.jpg` | photo | 720×720 px | placeholder |
| `public/media/yourPhotos-3.jpg` | photo | 736×968 px | placeholder |
| `public/media/yourPhotos-4.jpg` | photo | 720×897 px | placeholder |
| `public/media/yourPhotos-5.jpg` | photo | 1080×1340 px | placeholder |
| `public/media/yourPhotos-6.jpg` | photo | 720×887 px | placeholder |
| `public/media/yourPhotos-7.jpg` | photo | 1199×799 px | placeholder |
| `public/media/yourPhotos-8.png` | photo | 300×150 px | placeholder |
| `public/media/yourPhotos-9.jpg` | photo | 735×1303 px | placeholder |

Run it: `npm install && npm run dev`.
