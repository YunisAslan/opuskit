---
name: visual-qa
description: Compares the implemented site against the CHEEKY — Film-inspired Fashion House recipe and lists deviations. Use after finishing a section or page, before declaring work done, or when asked to review the design.
---

# Visual QA

Run the dev server, open each page (use a browser/screenshot tool if available), and compare against the recipe. Report deviations as a list: section → expected → actual → fix.

## Checklist
- [ ] Background is #4A1119; no other page background colors are introduced.
- [ ] Display text uses Anybody 800; body uses Spectral; no other families appear.
- [ ] Accent #A9D6FF covers < 5% of any viewport.
- [ ] Pages: Home · Collections · About · Contact · Size Guide · Gift Cards · Wholesale · FAQ · Journal · Sign In · Cookie Policy · Sign Up · Privacy Policy · Terms of Service · Shop — every page shares the same navbar and footer.
- [ ] Home section order: Hero.
- [ ] Collections section order: Collection → Lookbook.
- [ ] About section order: About → Editorial Story.
- [ ] Contact section order: Closing CTA.
- [ ] Size Guide section order: .
- [ ] Gift Cards section order: .
- [ ] Wholesale section order: .
- [ ] FAQ section order: FAQ.
- [ ] Journal section order: Journal.
- [ ] Sign In section order: .
- [ ] Cookie Policy section order: .
- [ ] Sign Up section order: .
- [ ] Privacy Policy section order: .
- [ ] Terms of Service section order: .
- [ ] Shop section order: Product Grid.
- [ ] Hero matches "Scroll-controlled video": A pinned 100svh stage; the video's playhead is mapped to scroll progress over ~300vh. Type appears at chapter points.
- [ ] Signature moment "Sideways scrolling gallery" is built on Collections — Lookbook, with its mobile and reduced-motion versions.
- [ ] Signature moment "Photos revealed like a curtain" is built on About — Editorial Story, with its mobile and reduced-motion versions.
- [ ] Signature moment "Footer revealed from underneath" is built on Footer, with its mobile and reduced-motion versions.
- [ ] Signature moment "List with a floating preview" is built on Shop — Product Grid, with its mobile and reduced-motion versions.
- [ ] Photos are shown as "Endless rows" (Continuous CSS/transform loop (duplicated track), slows on hover, pauses when off-screen).
- [ ] Scroll film: forward, fast and backward scrolling move the video with the scroll; every scene message appears on its own scene, one at a time (desktop and 390px).
- [ ] Layout: Overlay text in 5–6 columns at bottom-left; interstitial text centred in 8; section spacing Media sections are 100svh; text sections 120–160px padding.
- [ ] Absent: Heavy vintage filters.
- [ ] Absent: Fake film UI (sprocket holes).
- [ ] Absent: Cold, clinical palettes.
- [ ] Absent: A cream or beige page ground with a clay/terracotta accent.
- [ ] Absent: A near-black ground with one acid-green or orange accent, or tinted charcoal standing in for black.
- [ ] Absent: Small uppercase, letter-spaced monospace labels above every heading.
- [ ] Absent: Numbered markers (01 / 02) on content that is not a real sequence.
- [ ] Absent: Meta strings joined with middle dots or spaced em dashes, and "→" appended to links.
- [ ] Absent: One italic or coloured accent word inside an otherwise plain headline.
- [ ] Absent: Falling back to Inter, Space Grotesk, Syne or Fraunces instead of the recipe's fonts.
- [ ] Mobile (390px): no horizontal scroll, headlines re-broken intentionally, touch targets ≥ 44px.
- [ ] prefers-reduced-motion: every animation has its documented alternative.
- [ ] Every media element is rendered through the asset config layer; temporary assets are listed in the manifest.
- [ ] Lighthouse on mobile: LCP < 2.5s, CLS < 0.1.

Do not mark work complete while any item fails. Fix, then re-check.
