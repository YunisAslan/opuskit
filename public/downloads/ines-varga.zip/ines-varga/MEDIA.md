# Media for Ines Varga, maps drawn by hand

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/desk-glasses-map.jpg` | photo | 1917×2400 px | placeholder |
| `public/media/featuredWork-1.jpg` | photo | 2400×1682 px | placeholder |
| `public/media/featuredWork-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/featuredWork-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/featuredWork-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/process-palette.jpg` | photo | 2400×1596 px | placeholder |
| `public/media/process-path.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/process-sketch.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/process-supplies.jpg` | photo | 1528×2400 px | placeholder |
| `public/media/process-walk-sign.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/process-watercolour.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/projectPageCaseStudy/centro-on-foot-1.jpg` | photo | 2400×1029 px | placeholder |
| `public/media/projectPageCaseStudy/lake-loop-1.jpg` | photo | 2400×1029 px | placeholder |
| `public/media/projectPageCaseStudy/riverside-quarter-1.jpg` | photo | 2400×1029 px | placeholder |
| `public/media/projectPageCaseStudy/salt-isles-1.jpg` | photo | 2400×1029 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/centro-on-foot-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/lake-loop-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/riverside-quarter-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-7.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/projectPageGallery/salt-isles-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/work-vintage-stack.jpg` | photo | 1601×2400 px | placeholder |

Run it: `npm install && npm run dev`.
