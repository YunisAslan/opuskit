# Media for Kür Delta Watch — 2,140 tonnes out of the river so far

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/boat-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/boat-2.jpg` | photo | 2400×1598 px | placeholder |
| `public/media/boat-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/cleanup-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/cleanup-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/cleanup-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/cleanup-4.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/cleanup-5.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/delta-1.jpg` | photo | 2400×1349 px | placeholder |
| `public/media/delta-2.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/glove.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 12 s | left out |
| `public/media/heron-1.jpg` | photo | 2400×1618 px | placeholder |
| `public/media/heron-2.jpg` | photo | 2400×1317 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 12 s | left out |
| `public/media/pelicans.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/team-1.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/team-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/team-3.jpg` | photo | 2400×1602 px | placeholder |
| `public/media/volunteer-day.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/water-test.jpg` | photo | 1728×2170 px | placeholder |

Run it: `npm install && npm run dev`.
