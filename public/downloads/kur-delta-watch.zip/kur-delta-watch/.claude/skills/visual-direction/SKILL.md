---
name: visual-direction
description: "Applies the \"Kür Delta Watch — Neo-Brutalist Foundation\" visual direction: palette tokens, typography roles, spacing scale and hierarchy rules. Use when creating or restyling any page, section or component."
---

# Visual direction — Kür Delta Watch — Neo-Brutalist Foundation

Read `recipe/design.md`, `recipe/color.md` and `recipe/typography.md` before writing UI.

## How to apply
1. Use only the CSS variables in `src/styles/tokens.css` — never raw hex values in components.
2. Typography roles: display = Big Shoulders (800, clamp(3.5rem, 12vw, 11rem), lh 0.88, ls 0); heading = Big Shoulders; body = Hanken Grotesk 1rem/1.6; utility = Big Shoulders 0.02em.
3. Spacing: only values from the 8px scale in `recipe/layout.md`. Space between sections > space within sections.
4. One focal point per viewport. If two elements compete, reduce one.
5. Accent color is a signal: active state, one highlight per view.
6. Shape — Bold outline: rounded-button / rounded-card / rounded-media and shadow-card tokens only. 2px ink borders on every module; hard offset shadow that collapses on press; no blur shadows.
7. Menu — Menu with cards: Compact bar; opening it reveals 3–4 cards below, each a section of the site with a photo, title and 2–3 links.

## Principles
- Show the structure
- Flat color, hard edges
- Interaction feels physical

## Never
- Soft gradients
- Glassmorphism
- Delicate serif type
- A cream or beige page ground with a clay/terracotta accent
- A near-black ground with one acid-green or orange accent, or tinted charcoal standing in for black
- Small uppercase, letter-spaced monospace labels above every heading
- Numbered markers (01 / 02) on content that is not a real sequence
- Meta strings joined with middle dots or spaced em dashes, and "→" appended to links
- One italic or coloured accent word inside an otherwise plain headline
- Falling back to Inter, Space Grotesk, Syne or Fraunces instead of the recipe's fonts

## Self-check before finishing a component
- Does it use tokens only?
- Is there exactly one visual priority?
- Would it still look intentional in grayscale?
