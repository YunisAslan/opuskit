# Media for Inkwell & Moth — picture books by Nell Arden

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/book-koi.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/book-moths.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/book-rooster.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/book-sparrow.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/desk-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/desk-2.jpg` | photo | 2400×1602 px | placeholder |
| `public/media/desk-3.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/desk-4.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/desk-5.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/moth-specimens.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/portrait.jpg` | photo | 1602×2400 px | placeholder |
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/process-1.jpg` | photo | 2400×1590 px | placeholder |
| `public/media/process-2.jpg` | photo | 2400×1778 px | placeholder |
| `public/media/process-3.jpg` | photo | 1602×2400 px | placeholder |
| `public/media/process-4.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/sheki.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/spread-1.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/spread-2.jpg` | photo | 1602×2400 px | placeholder |
| `public/media/spread-3.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/spread-4.jpg` | photo | 1597×2400 px | placeholder |
| `public/media/spread-5.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/spread-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/spread-7.jpg` | photo | 1882×2400 px | placeholder |
| `public/media/spread-8.jpg` | photo | 1669×2400 px | placeholder |
| `public/media/studio.jpg` | photo | 2400×1590 px | placeholder |

Run it: `npm install && npm run dev`.
