# Media for Slow Atlas | Long-form travel essays

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/article-1.jpg` | photo | 2400×1800 px | placeholder |
| `public/media/article-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/article-3.jpg` | photo | 2400×1350 px | placeholder |
| `public/media/article-4.jpg` | photo | 2400×1591 px | placeholder |
| `public/media/article-5.jpg` | photo | 2400×1800 px | placeholder |
| `public/media/article-6.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/clip.mp4` | video | 1920x1090 px, 9 s | left out |
| `public/media/clips/categories.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/editorial-story.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/journal.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/navbar.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/newsletter.mp4` | video | 1280x720 px, 3 s | left out |
| `public/media/clips/piece-preloader.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/sig-curtain-reveal.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/clips/sig-giant-word-chapters.mp4` | video | 1280x726 px, 3 s | left out |
| `public/media/poster.jpg` | photo | 1440×900 px | placeholder |
| `public/media/story.avif` | photo | 2670×1780 px | placeholder |
| `public/media/team-1.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/team-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/team-3.jpg` | photo | 1603×2400 px | placeholder |

Run it: `npm install && npm run dev`.
