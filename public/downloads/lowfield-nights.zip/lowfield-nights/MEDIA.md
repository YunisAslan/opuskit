# Media for Lowfield Nights — Silent films, live scores, 12–14 June

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/artist-1.jpg` | photo | 1597×2400 px | placeholder |
| `public/media/artist-2.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/artist-3.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/artist-4.jpg` | photo | 2069×2400 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 25 s | left out |
| `public/media/location.jpg` | photo | 2400×1421 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 25 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 25 s | left out |
| `public/media/venue-1.jpg` | photo | 2400×1353 px | placeholder |
| `public/media/venue-2.jpg` | photo | 2084×2400 px | placeholder |
| `public/media/venue-3.jpg` | photo | 2400×961 px | placeholder |
| `public/media/venue-4.jpg` | photo | 2400×1800 px | placeholder |

Run it: `npm install && npm run dev`.
