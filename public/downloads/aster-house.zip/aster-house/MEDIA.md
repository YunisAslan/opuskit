# Media for Aster House, twelve houses above the Caspian

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/architect.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/cliff-1.jpg` | photo | 2400×1354 px | placeholder |
| `public/media/cliff-2.jpg` | photo | 2400×1800 px | placeholder |
| `public/media/detail-jug.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 21 s | left out |
| `public/media/hour-afternoon.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/hour-dawn.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/hour-dusk.jpg` | photo | 2400×2399 px | placeholder |
| `public/media/hour-evening.jpg` | photo | 1590×2400 px | placeholder |
| `public/media/hour-morning.jpg` | photo | 2400×2400 px | placeholder |
| `public/media/hour-noon.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 21 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/room-balcony.jpg` | photo | 1800×2400 px | placeholder |
| `public/media/room-bed.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 21 s | left out |
| `public/media/stair.jpg` | photo | 1600×2400 px | placeholder |
| `public/media/terrace-pool.jpg` | photo | 2400×1601 px | placeholder |
| `public/media/terrace-stone.jpg` | photo | 1603×2400 px | placeholder |

Run it: `npm install && npm run dev`.
