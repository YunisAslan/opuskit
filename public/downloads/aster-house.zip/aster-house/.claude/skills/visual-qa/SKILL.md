---
name: visual-qa
description: Compares the implemented site against the Aster House — Architectural Minimal Property Site recipe and lists deviations. Use after finishing a section or page, before declaring work done, or when asked to review the design.
---

# Visual QA

Run the dev server, open each page (use a browser/screenshot tool if available), and compare against the recipe. Report deviations as a list: section → expected → actual → fix.

## Checklist
- [ ] Background is #CDB58F; no other page background colors are introduced.
- [ ] Display text uses Literata 300; body uses Literata; no other families appear.
- [ ] Accent #1E3A8A covers < 5% of any viewport.
- [ ] Pages: Home · Residences · A house · Book a viewing — every page shares the same navbar and footer.
- [ ] Footer “Signature columns”: Dark band (text colour as ground): the logo large on the left (5 of 12 columns), 2–3 link columns with headings, then a hairline and one row: copyright left, legal links right.
- [ ] Home section order: Hero → Intro → Feature Rows → Product Grid → Gallery → Location → Closing CTA.
- [ ] Residences section order: Product Grid → Features → FAQ.
- [ ] A house section order: Product Highlight → Gallery → Feature Rows → Closing CTA.
- [ ] Book a viewing section order: Closing CTA → Location.
- [ ] Hero matches "Scroll-controlled video": A pinned 100svh stage; the video's playhead is mapped to scroll progress over ~300vh. Type appears at chapter points.
- [ ] Controls and forms use shadcn/ui (button, sheet, sonner, tooltip, navigation-menu, dropdown-menu, calendar, popover, select, form, label, toggle-group, card, badge, dialog, carousel, input, textarea, checkbox, slider, pagination, tabs, accordion, radio-group, breadcrumb) restyled to the recipe tokens and shape — no unstyled native select, date input or checkbox anywhere; the date field is a Calendar in a Popover.
- [ ] Sections with ready code are built from their component in src/components/sections/ (real copy and media through props, no placeholder text left) and styled only through the recipe tokens. Pass the framework link as `link` (Next.js: `link={Link}` from next/link) so in-site links navigate client-side and respect basePath; without it they render plain <a>.
- [ ] Kit piece "Soft fade between pages" (<PageFade/> from src/components/pieces/PageFade.tsx) is used on Whole site — every internal link; mount once in app/layout.tsx, unchanged in behaviour and styled only through the recipe tokens.
- [ ] Kit piece "Filling underline" (<UnderlineFill/> from src/components/pieces/UnderlineFill.tsx) is used on Every page — menu, footer and text links, unchanged in behaviour and styled only through the recipe tokens.
- [ ] Big idea “One thing guides the scroll” is visible on every page: pick one element from the first screen — the product, the logo mark, a drawn line or a simple shape in the accent colour — and let it leave the hero and travel down the page with the visitor, turning up beside each chapter.
- [ ] Chapters open as the big idea says: Each chapter opens where the motif comes to rest: the motif changes pose or size there, and the chapter title sits next to it.
- [ ] The site ends as the big idea says: The motif comes to rest in the footer, beside the brand name: the journey visibly ends.
- [ ] Signature moment "One shape travels down the page" is built on Home — Intro, with its mobile and reduced-motion versions.
- [ ] Signature moment "A footer worth reaching" is built on Footer, with its mobile and reduced-motion versions.
- [ ] Every page passes the award checklist in the recipe (one idea, one unforgettable moment per page, type scale contrast, motion choreography, mobile as its own composition, a designed ending).
- [ ] Video: public/media/heroVideo.mp4 and mobileVideoEncode.mp4 exist and were produced by prepare-video.sh (not raw browser uploads); file size ≤ 6 MB desktop / ≤ 3 MB mobile; poster images (posterImage.jpg, posterMobile.jpg) exist and load before the video.
- [ ] Video sharpness: ffprobe shows heroVideo.mp4 ≥ 1920 px wide and mobileVideoEncode.mp4 ≥ 1080 px tall — if not, re-run prepare-video.sh (it sharpens small sources) rather than letting the browser stretch it.
- [ ] Scroll film: forward, fast and backward scrolling move the video with the scroll; every scene message appears on its own scene, one at a time (desktop and 390px).
- [ ] Layout: Overlay text in 5–6 columns at bottom-left; interstitial text centred in 8; section spacing Media sections are 100svh; text sections 120–160px padding.
- [ ] Shape “Hairline”: buttons 4px, cards 6px, media 4px radius (rounded-button / rounded-card / rounded-media) — Buttons and cards are outlined, not filled (except the one primary action); 1px borders in the border token.
- [ ] Menu “Classic bar”: Full-width bar: logo left, 4–6 links and the primary action right, on the page ground with a hairline bottom border.
- [ ] Absent: Rounded, bubbly UI.
- [ ] Absent: Illustrations.
- [ ] Absent: Busy backgrounds.
- [ ] Absent: A cream or beige page ground with a clay/terracotta accent.
- [ ] Absent: A near-black ground with one acid-green or orange accent, or tinted charcoal standing in for black.
- [ ] Absent: Small uppercase, letter-spaced monospace labels above every heading.
- [ ] Absent: Numbered markers (01 / 02) on content that is not a real sequence.
- [ ] Absent: Meta strings joined with middle dots or spaced em dashes, and "→" appended to links.
- [ ] Absent: One italic or coloured accent word inside an otherwise plain headline.
- [ ] Absent: Falling back to Inter, Space Grotesk, Syne or Fraunces instead of the recipe's fonts.
- [ ] Mobile (390px): no horizontal scroll, headlines re-broken intentionally, touch targets ≥ 44px.
- [ ] prefers-reduced-motion: every animation has its documented alternative.
- [ ] Every media element is rendered through the asset config layer; temporary assets are listed in the manifest.
- [ ] Lighthouse on mobile: LCP < 2.5s, CLS < 0.1.

Do not mark work complete while any item fails. Fix, then re-check.
