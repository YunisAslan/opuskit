# Media for Fieldhouse, architects for old barns

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/about-2.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/about.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/case-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/case-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/case-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/case-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-10.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/gallery-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-3.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/gallery-4.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/gallery-5.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-6.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/gallery-7.jpg` | photo | 1919×2400 px | placeholder |
| `public/media/gallery-8.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery-9.jpg` | photo | 1919×2400 px | placeholder |
| `public/media/hero-mobile.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/hero.jpg` | photo | 2800×1575 px | placeholder |
| `public/media/location-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/location-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/project-1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/project-2.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/project-3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/project-4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/team-1.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/team-2.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/team-3.jpg` | photo | 1600×2000 px | placeholder |
| `public/media/team-4.jpg` | photo | 1600×2000 px | placeholder |

Run it: `npm install && npm run dev`.
