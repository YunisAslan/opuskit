# Media for Halden, wood-fired sauna and cold sea

This copy has the site's real code. Its photos and videos are not included — they belong to the original site.
Every photo is a flat placeholder of the same size, so the layout holds. Videos are left out; the page shows its poster until you add one.
Put your own files at the same paths (same size or aspect ratio) and the site uses them.

| File | Kind | Size | In this copy |
|---|---|---|---|
| `public/media/gallery1.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery2.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/gallery3.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery4.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/gallery5.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/heroVideo.mp4` | video | 1920x1080 px, 25 s | left out |
| `public/media/locationHomeArrival.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/locationHomeInside.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/locationVisitArrival.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/locationVisitInside.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/mobileVideoEncode.mp4` | video | 1080x1920 px, 25 s | left out |
| `public/media/posterImage.jpg` | photo | 1920×1080 px | placeholder |
| `public/media/posterMobile.jpg` | photo | 1080×1920 px | placeholder |
| `public/media/scrubReadyEncode.mp4` | video | 1920x1080 px, 25 s | left out |
| `public/media/secondaryPoster.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/servicePrivate.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/serviceQuiet.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/serviceSauna.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/serviceSea.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/serviceSmoke.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/serviceTubs.jpg` | photo | 1920×2400 px | placeholder |
| `public/media/stepArrive.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/stepHeat.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/stepRest.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/stepSea.jpg` | photo | 2400×1600 px | placeholder |
| `public/media/supportingImages.jpg` | photo | 1920×2400 px | placeholder |

Run it: `npm install && npm run dev`.
